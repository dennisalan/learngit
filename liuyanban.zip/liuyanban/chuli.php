<?php
header("Content-type: text/html; charset=utf-8"); 
session_start();
$account = $_POST["account"];
$pwd = $_POST["password"];


$conn = mysql_connect("localhost","root","root");
if(!$conn){
	die("连接数据库失败".$conn->connect_error);
}
mysql_select_db("my_db",$conn);


if (!empty($account) && !empty($pwd) ) {
	
	$sql = "select * from userdata where account = '".$account."'";
	$res = mysql_query($sql);
	
	
	$row = mysql_fetch_array($res);
	/*echo $row['password'];
	echo "<pre>";
	var_dump($row);*/
	if ($row['password'] == $pwd) {
		$_SESSION['username'] = $row['username'];
		if($row['type'] == '1'){
			echo "欢迎你，你是管理员！";
		} else {
			echo "欢迎你，你是普通用户!";
		}
		echo '<a href = "main.php">去留言板！<a/>';

		/*header('Location:D:\phpStudy\WWW\liuyanban\test\main.php');*/
	}
	/*while ($row = mysql_fetch_array($res)) {
		echo "string";
		if ($row['password'] == $pwd) {
			$_SESSION['account'] = $account;
			header('location:main.php');
			echo "1";
		} */else {
			echo "用户名或密码错误，请重新输入。";
			echo '<a href= "denglu.php">返回登录界面<a/>';
		}
} else {
	echo '<script>alert("用户名或密码不能为空！");</script>';
	echo '<a href= "denglu.php">返回登录界面<a/>';
}
mysql_close($conn);

?>