<?php
header("Content-type: text/html; charset=utf-8"); 
date_default_timezone_set('PRC');
session_start();

if (empty($_SESSION["username"])) {
	header("localtion:denglu.php");
	exit;
}

$conn = mysql_connect("localhost","root","root");
if(!$conn){
	die("连接数据库失败".$conn->connect_error);
}
mysql_select_db("my_db",$conn);

$title = $_POST["title"];
$comment = $_POST["nr"];
if (!$comment || !$title) {
	die("标题或留言内容不能为空!");
}

$username = $_SESSION["username"];
$time = date('Y-m-d H:i:s',time());
$isexist = 1;

$sql = " insert into liuyanban1 (id,title,username,comment,time,exist) values 
( NULL,'".$title."' ,'".$username."', '".$comment."','".$time."','".$isexist."')";
if(mysql_query($sql, $conn)){
	echo "留言成功！<br/>";
} else {
	die("error".mysql_error());
}
mysql_close($conn);
?>
<a href="main.php">查看留言板</a>