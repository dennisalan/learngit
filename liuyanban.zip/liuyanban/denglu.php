<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<title></title>
	<style>
	.aa{
		height: 200px;
		width: 300px;
		margin: 100px auto;
		border: 1px solid black;
		text-align: center;
		line-height:20px;
		padding-top: 50px;
	}
	</style>
<body>
</head>

</SCRIPT> 
<div class="aa">
<form method="post" action="chuli.php">
<div>用户名:<input type="text" name="account"/></div></br>
<div>密码&nbsp;&nbsp;&nbsp;:<input type="password" name="password"/></div></br>
<input type="submit" value="登录"/>&nbsp&nbsp
<a href="register.php">注册新账号</a>
</form>
</div>
</body>
</html>
