<center><h1>花开人往留言板</h1></center>
<?php

header("Content-type: text/html; charset=utf-8"); 
session_start();
if (empty($_SESSION["username"])) {
	header("location:denglu.php");
	exit;
}
$conn = mysql_connect("localhost","root","root");
if(!$conn){
	die("连接数据库失败".$conn->connect_error);
}
mysql_select_db("my_db",$conn);

$username = $_SESSION["username"];

echo "<h2>欢迎你! &nbsp".$username."</br><h2/>";


$sql2 = "select * from liuyanban1 where exist = '1' order by id";
$result1 = mysql_query($sql2);
if (!mysql_fetch_array($result1) ) {
	echo "当前留言板内容为空，快去留言吧!";
} else{
		$pagesize = 5;
		$SQL = "select * from liuyanban1";
		$result = mysql_query($SQL);
		$total = mysql_num_rows($result);
		$totalpage = ceil($total/$pagesize);

		if (isset($_GET['page']) && $_GET['page'] <= $totalpage) {
			$thispage = $_GET['page'];
		} else {
			$thispage = 1;
		}
		$thispage = ($thispage-1)*$pagesize;

		$SQL = "select * from liuyanban1 limit $thispage,$pagesize";
		$result2 = mysql_query($SQL);
		while($rows = mysql_fetch_array($result2)){//这两句很精髓，记住mysql_fetch_array函数带给你的困扰.mmp
			
			?>
			<center>
			<table width="750" border="0" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
				<tr bgcolor="#eff3ff">
						<td>标题：<?php echo $rows['title']; ?></td>
						<td>时间: <?php echo $rows['time']; ?></td>
				</tr>
				<tr bgcolor="#eff3ff">
						<td width="375">用户:<?php echo $rows['username'] ?></td>
						<td width="375"></td>
				</tr>
				<tr>
						<td width="750">内容:<?php echo $rows['comment'] ?>
			
				</tr><br>
			</table>
			</center>
			<center>
<?php
		}
		for ($i=1; $i <= $totalpage ; $i++) { 
		echo '<a href ="?page='.$i.'">'.$i.'</a>';
}
}
mysql_close($conn);
?>
</center>
<center>
<a href="fabu.php">去写留言</a>
<a href="delete.php">删除留言</a>
<a href="exit.php">退出系统</a></center>
<br/><br/><br/>