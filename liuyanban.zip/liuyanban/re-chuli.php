<meta charset="utf-8">
<?php
/*session_start();*/
$account = $_POST['account'];
$pwd =  $_POST["password"];
$name = $_POST["username"];

$conn = mysql_connect("localhost","root","root");
if(!$conn){
	die("连接数据库失败".$conn->connect_error);
}
mysql_select_db("my_db",$conn);

/*$sql = "select account from userdata";
$res = mysql_query($sql);
while ($row = mysql_fetch_array($res)) {
	echo "<pre>";
	echo $row['account'];
}*/

if (!empty($account) && !empty($pwd) && !empty($name)) {

	$sql1 = "select account from userdata";
	$res = mysql_query($sql1);	

	while($row = mysql_fetch_array($res))
	{
		if ($row['account'] == $account) {

			echo '<script>alert("用户名已存在！");</script>';
			echo "<a href = 'register.php'>返回注册界面</a><br/>";
			die();
		} else {

 			$sql = "insert into userdata(account, password, username,type) 
 			values ('$_POST[account]','$_POST[password]','$_POST[username]',0)";
		
			if (mysql_query($sql, $conn) == TRUE) {

				echo "账号注册成功。<br/>";
				
			}
		}
	}
} else {
			echo "<a href = 'register.php'>返回注册界面</a><br/>";
			die('不允许注册信息为空!');
}
mysql_close($conn);
?>
<a href="denglu.php">返回登录界面</a>