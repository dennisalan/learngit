<html>
<head>
		<meta charset="utf-8">
	<h2>欢迎留言</h2>
	</head>
<body>
	<form method="post" action="nr-chuli.php">
	标题：<input type="text" name="title"><br/>
	内容：<textarea name="nr" cols="30" rows="10"></textarea>
	<input type="submit" value="发送"/><br/>
	<a href="main.php">查看留言板</a>
	</form>
</body>
</html>
