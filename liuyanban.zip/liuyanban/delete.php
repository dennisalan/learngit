<center><h1>花开人往留言板</h1></center>
<?php

header("Content-type: text/html; charset=utf-8"); 
session_start();
if (empty($_SESSION["username"])) {
	header("location:denglu.php");
	exit;
}
$conn = mysql_connect("localhost","root","root");
if(!$conn){
	die("连接数据库失败".$conn->connect_error);
}
mysql_select_db("my_db",$conn);

$username = $_SESSION["username"];

$sql1 = "select type from userdata where username ='".$username."'";
$result = mysql_query($sql1);
$type = mysql_fetch_array($result);

if ($type['type'] == 0) {
	echo "<script>alert('你不是管理员，没有删除留言的权限');</script>";
	echo "<a href = 'main.php'>返回主页</a>";
} else{

$sql2 = "select * from liuyanban1 where exist = '1' order by id";
$result1 = mysql_query($sql2);
if (!mysql_fetch_array($result1) ) {
	echo "无留言!";
} else{
		$result2 = mysql_query($sql2);
		while($rows = mysql_fetch_array($result2)){
			
			?>
			<center>
			<table width="750" border="0" cellpadding="5" cellspacing="1" bgcolor="#add3ef">
				<tr bgcolor="#eff3ff">
						<td width="375">标题：<?php echo $rows['title']; ?></td>
						<td width="375">时间: <?php echo $rows['time']; ?></td>
				</tr>
				<tr bgcolor="#eff3ff">
						<td width="375">用户:<?php echo $rows['username']; ?></td>
						<td width="375"></td>
				</tr>
				<tr>
						<td>内容:
						<?php
						echo $rows['comment'] ;
						$id = $rows['id'];
						echo"<a href = delete1.php?id=".$id."> 删除</a>";
					    ?></td>		
				</tr><br>
			</table>
			</center>
<?php
		}
}
}
mysql_close($conn);
?>