<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
	<title></title>
	<style>
	.aa{
		height: 200px;
		width: 300px;
		margin: 100px auto;
		border: 1px solid black;
		text-align: center;
		line-height:20px;
		padding-top: 50px;
	}
	</style>
</head>
<body>
<div class="aa">
<form method="post" action="re-chuli.php">
<div>账号&nbsp;&nbsp;&nbsp;:<input type="text" name="account"></div></br>
<div>密码&nbsp;&nbsp;&nbsp;:<input type="text" name="password"/></div></br>
<div>用户名:<input type="text" name="username"/></div></br>
<input type="submit" value="保存"/>
</div>
</form>
</body>
</html>