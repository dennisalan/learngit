<?php
header("Content-type: text/html; charset=utf-8");
$conn = mysql_connect('localhost','root','root');
mysql_select_db('my_db');
$exec = 'update liuyanban1 set exist = false where id ='.$_GET['id'];
mysql_query($exec) or die('删除失败'.mysql_error());
echo "<script>alert('留言删除成功');</script>";
mysql_close($conn);
echo "<a href = main.php>返回留言板</a>";
?>